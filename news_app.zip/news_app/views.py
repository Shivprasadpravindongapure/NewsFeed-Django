import requests
from django.shortcuts import render

# Replace with your own News API Key
NEWS_API_KEY = 'a076fbe731d644c6b895c59f062c2ef7'
NEWS_API_URL = 'https://newsapi.org/v2/top-headlines'

CATEGORY_MAPPING = {
    'gaming': 'gaming',
    'politics': 'politics',
    'education': 'education'
}

def fetch_news_by_category(category):
    """Fetch news articles by category from News API."""
    category_param = CATEGORY_MAPPING.get(category, 'general')  # Default to 'general' if no category matched
    params = {
        'apiKey': NEWS_API_KEY,
        'category': category_param,
        'country': 'us',  # You can change the country as needed
    }
    response = requests.get(NEWS_API_URL, params=params)
    if response.status_code == 200:
        return response.json()['articles']
    return []

def home(request):
    category = request.GET.get('category', 'general')  # Default category is 'general'
    headlines = fetch_news_by_category(category)
    return render(request, 'news_app/home.html', {'headlines': headlines})
